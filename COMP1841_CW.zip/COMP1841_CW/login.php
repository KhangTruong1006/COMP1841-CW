<?php
session_start();
include "includes/DatabaseConnection.php";
include "includes/DatabaseFunctions.php";

// check if login form is submited
if (isset($_POST['login'])){
    
    // assign variable to post values
    $email = trim($_POST['login_email']);
    $password = trim($_POST['login_password']);
    $account = getAccount($pdo,$email);
    
    if ($email === '' || $password === ''){
        $_SESSION['login_email'] = $email;
        $_SESSION['login_password'] = $password;
        $_SESSION['error'] = $allFieldsRequired;
        header('Location: login.php');
        exit;
    }
    else {
        try{
            // check if email exist
            if($account->rowCount() > 0){
                $account = $account->fetch();
                // verify input password
                if(password_verify($password,$account['user_password'])){
                    $_SESSION['user_id']=$account['user_id'];
                    $_SESSION['username']=$account['username'];
                    $_SESSION['email'] = $account['email'];
                    //User role for access
                    if ($account['user_role']=='user'){
                        $_SESSION['access'] = 'user';
                    }
                    else {
                        $_SESSION['access'] = 'admin';
                    }
                    header('location: index.php');
                }
                else{
                    // return values to the user
                    $_SESSION['login_email'] = $email;
                    $_SESSION['login_password'] = $password;
                    $_SESSION['error'] = 'Incorrect Password';

                    ob_start();
                    include "templates/login/login.html.php";
                    $output = ob_get_clean();
                }
            } 
            else {
                // return the values to the user
                $_SESSION['login_email'] = $email;
                $_SESSION['login_password'] = $password;
                $_SESSION['error'] = 'No account found';
                
                ob_start();
                include "templates/login/login.html.php";
                $output = ob_get_clean();
            }
        }

        catch(PDOException $e){
            $_SESSION['error'] = $e -> getMessage();
        }
    }
} 
else {
    ob_start();
    include "templates/login/login.html.php";
    $output = ob_get_clean();
}

include "templates/login_layout.html.php";