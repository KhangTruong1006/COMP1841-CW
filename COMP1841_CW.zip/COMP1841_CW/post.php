<?php session_start();
include 'includes/DatabaseConnection.php';
include 'includes/DatabaseFunctions.php';
try {
    $post = getPostDetails($pdo,$_GET['post_id']);
    $answers = getAnswers($pdo,$_GET['post_id']);

    ob_start();
    include 'templates/public/post.html.php';
    $output = ob_get_clean();
}
catch (PDOException $e){
    $output = "Database error: " . $e->getMessage();
}

include 'templates/layout.html.php';