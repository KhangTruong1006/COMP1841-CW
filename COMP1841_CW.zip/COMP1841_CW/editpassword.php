<?php
session_start();
include 'includes/DatabaseConnection.php';
include 'includes/DatabaseFunctions.php';
try{
    $user_id = $_SESSION['user_id'];
    $account = getAccount($pdo,$_SESSION['email'])->fetch();

    if (isset($_POST['submit'])){
        $new_password = trim($_POST['new_password']);
        $confirm_password = trim($_POST['confirm_password']);
        $current_password = trim($_POST['current_password']);

        // chech if any is white space
        if ($new_password === '' || $confirm_password === '' || $current_password === ''){
            $_SESSION['error'] = $allFieldsRequired;
            header('Location: editpassword.php');
            exit;
        }

        // check if new password match confirm password
        if ($new_password != $confirm_password){
            $_SESSION['error'] = 'Password does not match';
            header('Location: editpassword.php');
            exit;
        }

        else {
            // verify password
            if(password_verify($current_password, $account['user_password'])){
                $_SESSION['success'] = 'Changed password successfully';
                $password = password_hash($new_password, PASSWORD_DEFAULT);
                updateNewPassword($pdo,$password,$user_id);
                header('Location: editpassword.php');
            }
            else {
                $_SESSION['error'] = 'Wrong password';
                header('Location: editpassword.php');
                exit;
            }
        }
    }
 
    else{
        ob_start();
        include 'templates/editprofile/editpassword.html.php';
        $output = ob_get_clean();  
    } 
}

catch(PDOException $e) {
    $output = 'Database error: '.$e->getMessage();
}

include 'templates/layout.html.php';