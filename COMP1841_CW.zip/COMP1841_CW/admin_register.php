<?php
session_start();
include "includes/DatabaseConnection.php";
include "includes/DatabaseFunctions.php";

$admin_code = 'admin1006';

try{
    if (isset($_POST['submit'])) {
        $code = trim($_POST['admin_code']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $account = getAccount($pdo,$email);
        
        //check white space
        if ($code === '' || $email === '' || $password === '') {
            $_SESSION['error'] = $allFieldsRequired;
            header('Location: admin_register.php');
            exit;
        }
        
        // check if the input code is correct
        if($code != $admin_code) {
            $_SESSION['error'] = 'Incorrect code';
            header('Location: admin_register.php');
            exit;
        }

        if($account->rowCount() > 0){
            $account = $account->fetch();
            if(password_verify($password,$account['user_password'])){
                if($account['user_role'] == 'admin'){
                    $_SESSION['error'] = 'This account is already authorised';
                    header('Location: admin_register.php');
                    exit; 
                }

                else {
                    $_SESSION['success'] = 'You have been authorised';
                    authoriseAccount($pdo,$email);
                    header('Location: admin_register.php');
                }
            }

            else {
                $_SESSION['error'] = 'Incorrect password';
                header('Location: admin_register.php');
                exit; 
            }
        }
        
        else {
            $_SESSION['error'] = 'No account found';
            header('Location: admin_register.php');
            exit; 
        }
    }
    
    else{
        ob_start();
        include "templates/login/admin_register.html.php";
        $output = ob_get_clean();
    }
}

catch(PDOException $e){
    $output= "Error login". $e->getMessage();
}

include "templates/login_layout.html.php";