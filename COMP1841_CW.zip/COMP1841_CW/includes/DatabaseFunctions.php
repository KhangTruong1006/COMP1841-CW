<?php
// messages
$allFieldsRequired = 'All fields required';
$usernameTaken = 'Username is already taken';

function query($pdo,$sql,$parameters = []){
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}

// --insert functions--
function insertAccount($pdo,$email,$username,$firstname,$lastname,$password){
    $sql= "INSERT INTO user_profile (username, first_name, last_name,email,user_password, user_role, create_date)
    VALUES (:username,:firstname,:lastname,:email,:user_password,'user', CURDATE());";
    $parameters = [
        ':username'=>$username,
        ':firstname'=>$firstname,
        ':lastname'=>$lastname,
        ':email'=> $email,
        ':user_password'=>$password
    ];
    query($pdo,$sql,$parameters);
}

function insertAnswer($pdo,$content, $user_id,$post_id){
    $parameters = [':content'=> $content,':user_id'=> $user_id,':post_id'=> $post_id];
    $sql = 'INSERT INTO answer (content, user_id, post_id) VALUES (:content,:user_id,:post_id);';
    query($pdo,$sql,$parameters);
}

function insertModule($pdo,$module_name){
    $parameters =[':module_name'=> $module_name];
    $sql = 'INSERT INTO module(module_name) VALUES (:module_name)';
    query($pdo,$sql,$parameters);
}


// --Get functions--
// Get account function
function getAccount($pdo,$email){
    $parameters = [':email' => $email];
    $sql = 'SELECT * FROM user_profile WHERE email = :email';
    $query = query($pdo,$sql,$parameters);
    return $query;
}

function getAccountById($pdo,$user_id){
    $parameters = [':user_id'=> $user_id];
    $sql = 'SELECT * FROM user_profile WHERE user_id= :user_id';
    $query = query($pdo,$sql,$parameters);
    return $query->fetch();
}

function getUsername($pdo,$username){
    $parameters = [':username'=> $username];
    $sql = 'SELECT * FROM user_profile WHERE username= :username';
    $query = query($pdo,$sql,$parameters);
    return $query;
}

function getUsers($pdo){
    $sql = 'SELECT * FROM user_profile WHERE user_role = "user"';
    $query = query($pdo,$sql);
    return $query;
}

// Get post functions
function getPosts($pdo){
    $sql = 'SELECT p.Post_id, p.title, p.creation_date, u.username, m.module_name 
    FROM post AS p
    INNER JOIN module AS m ON p.module_id = m.module_id
    INNER JOIN user_profile AS u ON p.user_id = u.user_id
    ORDER BY post_id DESC;';
    $query = query($pdo,$sql);
    return $query;
}

function getPersonalPosts($pdo,$user_id){
    $parameters = [':user_id'=> $user_id];
    $sql ='SELECT p.Post_id, p.title, p.creation_date, m.module_name
    FROM post AS p
    INNER JOIN module AS m ON p.module_id = m.module_id
    WHERE p.user_id = :user_id
    ORDER BY p.Post_id DESC';
    $query = query($pdo,$sql,$parameters);
    return $query;
}

function getPostDetails($pdo,$post_id) {
    $parameters = [':post_id'=> $post_id];
    $sql = 'SELECT p.*, u.username, m.module_name 
    FROM post AS p
    INNER JOIN user_profile AS u ON u.user_id = p.user_id
    INNER JOIN module AS m ON m.module_id = p.module_id
    WHERE p.Post_id = :post_id';
    $query = query($pdo,$sql,$parameters);
    return $query->fetch();
}

function getAnswers($pdo,$post_id){
    $parameters = [':post_id'=>$post_id];
    $sql = 'SELECT a.* , u.username 
    FROM answer AS a
    INNER JOIN user_profile AS u ON a.user_id = u.user_id
    WHERE post_id = :post_id
    ORDER BY a.answer_id DESC;';
    $query = query($pdo,$sql,$parameters);
    return $query;
}

// get module functions
function getModules($pdo){
    $sql = 'SELECT * FROM module';
    $query = query($pdo,$sql);
    return $query;
}

function getModuleName($pdo,$module_id){
    $parameters = [':module_id'=>$module_id];
    $sql = 'SELECT * FROM module WHERE module_id = :module_id';
    $query = query($pdo,$sql,$parameters);
    return $query;
}

function getAdminEmails($pdo) {
    $sql = 'SELECT user_id, username, first_name, last_name, email, user_role FROM user_profile WHERE user_role = "admin";';
    $query = query($pdo,$sql);
    return $query;
}


// --Delete functions--
function deletePost($pdo,$post_id){
    $parameters = [':post_id'=> $post_id];
    $sql = 'DELETE FROM post WHERE Post_id = :post_id';
    query($pdo,$sql,$parameters);
}

function deletePostAnswers($pdo,$post_id){
    $parameters = [':post_id'=> $post_id];
    $sql = 'DELETE FROM answer WHERE Post_id = :post_id';
    query($pdo,$sql,$parameters);
}

function deleteAnswer($pdo,$answer_id){
    $parameters = [':answer_id'=> $answer_id];
    $sql = 'DELETE FROM answer WHERE answer_id = :answer_id';
    query($pdo,$sql,$parameters);
}

function deleteUserAnswers($pdo,$user_id){
    $parameters = [':user_id'=>$user_id];
    $sql = 'DELETE FROM answer WHERE user_id = :user_id';
    query($pdo,$sql,$parameters);
}

function deleteUserPosts($pdo,$user_id){
    $parameters = [':user_id'=> $user_id];
    $sql = 'DELETE FROM post WHERE user_id = :user_id';
    query($pdo,$sql,$parameters);
}

function deleteUser($pdo,$user_id){
    $parameters = [':user_id'=>$user_id];
    $sql = 'DELETE FROM user_profile WHERE user_id = :user_id';
    query($pdo,$sql,$parameters);
}

function deleteModule($pdo,$module_id){
    $parameters = [':module_id'=> $module_id];
    $sql = 'DELETE FROM module WHERE module_id = :module_id';
    query($pdo,$sql,$parameters);
}


// --Update functions--
function updatePostModule($pdo,$module_id){
    $parameters = [':module_id' => $module_id];
    $sql = 'UPDATE post SET module_id = 1 WHERE module_id = :module_id';
    query($pdo,$sql,$parameters);
}

function updateNewEmail($pdo,$email,$user_id) {
    $parameters = [':email'=> $email,':user_id'=> $user_id];
    $sql = 'UPDATE user_profile SET
        email = :email
        WHERE user_id = :user_id;';
    query($pdo,$sql,$parameters);
}

function updateNewUsername($pdo,$username,$user_id) {
    $parameters = [':username'=>$username,':user_id'=>$user_id];
    $sql = 'UPDATE user_profile SET
        username = :username
        WHERE user_id = :user_id;';
    query($pdo,$sql,$parameters);
}

function updateUserFullname($pdo,$firstname,$lastname,$user_id) {
    $parameters = [':first_name'=> $firstname, ':last_name'=> $lastname, ':user_id'=> $user_id];
    $sql ='UPDATE user_profile SET
        first_name = :first_name,
        last_name = :last_name
        WHERE user_id = :user_id;';
    query($pdo,$sql,$parameters);
}

function updateNewPassword($pdo,$password,$user_id) {
    $parameters = [':user_password'=> $password, ':user_id'=>$user_id];
    $sql = 'UPDATE user_profile SET
        user_password = :user_password
        WHERE user_id = :user_id;';
    query($pdo,$sql,$parameters);
}

function updateModuleName($pdo,$module_id,$module_name){
    $parameters = [':module_id'=>$module_id, ':module_name'=>$module_name];
    $sql = 'UPDATE module SET module_name = :module_name WHERE module_id = :module_id';
    query($pdo,$sql,$parameters);
}

function updatePost($pdo,$post_id, $title, $content, $module_id){
    $parameters = [
        ':post_id' => $post_id,
        ':title' => $title,
        ':content' => $content,
        ':module_id'=> $module_id
    ];
    $sql = 'UPDATE post SET 
        title = :title,
        content = :content,
        module_id = :module_id
        WHERE Post_id =:post_id;';
    query($pdo,$sql,$parameters);
}


// others
function authoriseAccount($pdo,$email) {
    $parameters = [':email' => $email];
    $sql = 'UPDATE user_profile SET
        user_role = "admin" 
        WHERE email = :email ;';
    query($pdo,$sql,$parameters);
}

function createPost($pdo,$title,$content,$image,$user_id,$module_id){
    $parameters = [':title'=> $title,':content'=> $content, ':post_image'=> $image, ':user_id'=> $user_id, ':module_id'=>$module_id];
    $sql = 'INSERT INTO post(title,content,image,creation_date,user_id,module_id)
    VALUES (:title, :content,:post_image,CURDATE(),:user_id,:module_id);' ;
    query($pdo, $sql, $parameters);
}