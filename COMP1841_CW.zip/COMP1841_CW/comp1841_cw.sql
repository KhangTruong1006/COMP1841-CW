-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2024 at 06:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comp1841_cw`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `answer_id` int(11) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`answer_id`, `content`, `user_id`, `post_id`) VALUES
(1, 'This is a first comment. And this one is done by using smartphone', 1, 1),
(2, 'This is a comment', 2, 1),
(4, 'test', 2, 2),
(5, 'hello', 3, 5),
(6, 'this is a comment', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `module_id` int(11) NOT NULL,
  `module_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`module_id`, `module_name`) VALUES
(1, 'General'),
(3, 'Coding'),
(4, 'Business'),
(5, 'Exam'),
(7, 'Graphics'),
(8, 'Test'),
(9, 'Health');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `Post_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `creation_date` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`Post_id`, `title`, `content`, `image`, `creation_date`, `user_id`, `module_id`) VALUES
(1, 'First post', 'Hello, you are reading this from the owner. This is a first post of the website, have a nice day', 'day.jpg', '2024-12-11', 1, 1),
(2, 'Post 2 Ask post', 'This is a website concept image', 'Post2Ask_concept.png', '2024-12-12', 2, 3),
(5, 'This is a post', 'Post as a regular user', NULL, '2024-12-12', 3, 8),
(6, 'Have a nice day to every persons', 'Have a nice day everyone in every places of the world', 'nice_day.jpg', '2024-12-12', 4, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_role` varchar(20) DEFAULT NULL,
  `create_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`user_id`, `username`, `first_name`, `last_name`, `email`, `user_password`, `user_role`, `create_date`) VALUES
(1, 'khangtheowner', 'Khang', 'Truong', 'truongnhatkhang1006@gmail.com', '$2y$10$25uibmhT6dXlkGE5d2JJg.WvuCi/di7PtZOaQGBMATNHctQtDvSQi', 'admin', '2024-12-11'),
(2, 'testing_account01', 'Alex', 'Smith', 'khangtruong2k5@gmail.com', '$2y$10$wmWKfs3.1CjV1jq60IkPNeS/H5YOvI1EASSwFJObgCNkwR5eyCQeq', 'admin', '2024-12-12'),
(3, 'real_panici', 'Alex', 'Johnson', 'panici9571@angewy.com', '$2y$10$dpWeJUnuMPotJ92bH2EbsOYjK4fv9aPfcvkDCbmqUw.dhhQI33Dou', 'user', '2024-12-12'),
(4, 'test_account', 'Tom', 'Jackson', 'xodosik935@lineacr.com', '$2y$10$CrJNU4iA/ctltXeC3.JHw.BQUBkQXz3F0AVAenwInhebjdJJ7Fo8u', 'user', '2024-12-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `fk_answer_user_id` (`user_id`),
  ADD KEY `fk_answer_post_id` (`post_id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`Post_id`),
  ADD KEY `fk_post_user_id` (`user_id`),
  ADD KEY `fk_module_id` (`module_id`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `unique_username` (`username`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `Post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `fk_answer_post_id` FOREIGN KEY (`post_id`) REFERENCES `post` (`Post_id`),
  ADD CONSTRAINT `fk_answer_user_id` FOREIGN KEY (`user_id`) REFERENCES `user_profile` (`user_id`);

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `fk_module_id` FOREIGN KEY (`module_id`) REFERENCES `module` (`module_id`),
  ADD CONSTRAINT `fk_post_user_id` FOREIGN KEY (`user_id`) REFERENCES `user_profile` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
