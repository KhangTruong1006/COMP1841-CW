<?php
session_start();
try {
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';

    $post_id = $_POST['post_id'];
    deletePostAnswers($pdo,$post_id);
    deletePost($pdo,$post_id);
    header('Location: personal_posts.php');
    exit;
}

catch(PDOException $e){
    $output = "Database error: " . $e->getMessage();
}