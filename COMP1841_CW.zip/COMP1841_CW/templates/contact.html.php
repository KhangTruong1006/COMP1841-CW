<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 p-3 my-3 shadow">
        <div class="text-center">
            <h2>Contact Form</h2>
        </div>
        <form action="" method = "post" class="w-75 mx-auto">
            
            <p>
                <small>
                    <?php 
                        if(isset($_SESSION['error'])){
                            echo "
                                <div class='text-danger h5'>
                                ".$_SESSION['error']."
                                </div>
                            ";
                            unset($_SESSION['error']);
                        }
                        if(isset($_SESSION['success'])){
                            echo"
                            <div class= 'text-success text-center'>
                                You can login no! <a href='login.php' class='alert-link>Login</a>'".$_SESSION['success']."
                            <div/>
                            ";
                            unset($_SESSION['success']);
                        }
                        ?>
                </small>
            </p>
        
            <h4>Name<span class="text-danger">*</span></h4>
            <div class="form-floating">
                <input type="text" class="form-control" name="name" placeholder="" required>
                <label for="name" class="form-label">Name</label>
            </div>

            <h4>Subject<span class="text-danger">*</span></h4>
            <div class="form-floating">
                <input type="text" class="form-control" name="subject" placeholder="" required>
                <label for="subject" class="form-label">Subject</label>
            </div>
            
            <h4 class="mt-3">Message<span class="text-danger">*</span></h4>
            <div class="form-floating">
                <textarea class="form-control" placeholder="" name="message" style="height: 100px; resize:none"></textarea>
                <label for="message">Message</label>
            </div>

            <h4 class="mt-3">Send to</h4>
            <select name="admins" id="admins" class="form-select form-select-sm" required>
                <?php foreach($admins as $admin): ?>
                    <option value = "<?=htmlspecialchars($admin['email'],ENT_QUOTES,'UTF-8'); ?>">
                        <?=htmlspecialchars($admin['first_name'].' '.$admin['last_name'],ENT_QUOTES,'UTF-8');?>
                        (<?=htmlspecialchars($admin['email'],ENT_QUOTES,'UTF-8');?>)
                    </option>
                <?php endforeach; ?>
            </select>

            <div class="d-flex justify-content-end mt-3">
                <a href="posts.php" class="btn btn-outline-danger col-lg-2  me-lg-5 me-sm-3">Cancel</a>
                <input type="submit" name="send" value="Send" class = "col-lg-2 btn btn-primary">
            </div>
        </form>
    </div>
</section>