<section class="min-vh-100 background_theme">
    <div class="container">
        <div class= "row align-items-center justify-content-center my-4" >
            <div class="col-sm-8 col-md-6 col-lg-4 bg-white rounded p-4 shadow">
                <div class="row justify-content-center mb-4 display_web">
                    <h1 class="display-1 text-center ">Post 2 Ask</h1>
                    <hr width="100%" size="1">
                    <h1 class="display-6 text-center" id="login">Register</h1>
                    <div class= "my-1">
                        <?php
                            if(isset($_SESSION['error'])){
                                echo "
                                <div class= 'alert alert-danger text-center h6'>
                                    ".$_SESSION['error']."
                                </div>
                                ";
                                unset($_SESSION['error']);
                            }

                            if(isset($_SESSION['success'])){
                                echo "
                                <div class= 'alert alert-success text-center h6'>
                                    ".$_SESSION['success']."
                                </div>
                                ";
                                unset($_SESSION['success']);
                            }
                        ?>
                    </div>
                </div>
                <form action="" method="post">
                    <!--Email-->
                   <div class="mb-4">
                        <label for="register_email" class="form-label">Email</label>
                        <input type ="email" class= "form-control" name="register_email" id="register_email" placeholder="abc@email.com" required
                        value ="<?php echo (isset($_SESSION['register_email'])) ? $_SESSION['register_email'] : ''; unset($_SESSION['register_email']) ?>">
                   </div> 
                   
                   <!--Username-->
                   <div class="mb-4">
                        <label for="username" class="form-label">Username</label>
                        <input type ="text" class= "form-control" name="username" id="username" placeholder="johnsmith_123" required aria-describedby="username_requirements"
                        value = "<?php echo (isset($_SESSION['username'])) ? $_SESSION['username'] : ''; unset($_SESSION['username']) ?>">
                        <div class="form-text" id="username_requirements">Only lowercase letters, numbers and underscore</div>
                   </div> 
                    
                   <!--First Name-->
                   <div class="mb-4">
                        <label for="firstname" class="form-label">First name</label>
                        <input type ="text" class= "form-control" name="firstname" id="firstname" placeholder="John" required
                        value = "<?php echo (isset($_SESSION['firstname'])) ? $_SESSION['firstname'] : ''; unset($_SESSION['firstname']) ?>">
                   </div> 
                    
                   <!--Last Name-->
                   <div class="mb-4">
                        <label for="lastname" class="form-label">Last name</label>
                        <input type ="text" class= "form-control" name="lastname" id="lastname" placeholder="Smith" required
                        value ="<?php echo (isset($_SESSION['lastname'])) ? $_SESSION['lastname'] : ''; unset($_SESSION['lastname']) ?>">
                   </div> 
                    
                   <!--Password-->
                   <div class="mb-4">
                        <label for ="register_password" class= "form-lable">Password</label>
                        <input type="password" class="form-control" name = "register_password" id="register_password" placeholder ="8-20 characters long" minlength="8" maxlength="20" required
                        value = "">
                   </div>
                   
                   <!--Confirm password-->
                   <div class="mb-4">
                        <label for ="confirm_password" class= "form-lable"> Confirm Password</label>
                        <input type="password" class="form-control" name = "confirm_password" id="confirm_password" placeholder ="8-20 characters long" minlength="8" maxlength="20" required
                        value = "">
                        <button class="btn btn-success form-control mt-4 w-100" name="register">Sign Up</button>
                   </div>
                </form>
                <hr width="100%" size="1">
                <p class="mb-0 text-center">
                    Have an account ? <a href="login.php" class="text-decoration-none">Login</a>
                </p>
            </div>
        </div>
    </div>
</section>
