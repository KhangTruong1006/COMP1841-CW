<section class="min-vh-100 background_theme">
    <div class="container">
        <div class= "row vh-100 align-items-center justify-content-center" >
            <div class="col-sm-8 col-md-6 col-lg-4 bg-white rounded p-4 shadow">
                <div class="row justify-content-center mb-4 display_web">
                    <h1 class="display-1 text-center ">Post 2 Ask</h1>
                    <hr width="100%" size="1">
                    <h1 class="display-6 text-center" id="login">Login</h1>
                    <div class= "my-1">
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='alert alert-danger text-center h6'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                        ?>
                    </div>
                </div>

                <form action="" method="post">
                    <!--Email-->
                   <div class="mb-4">
                        <label for="login_email" class="form-label">Email</label>
                        <input type ="email" class= "form-control" name="login_email" id="email" aria-describedby="emailHelp" placeholder="abc@email.com" required
                        value="<?php echo (isset($_SESSION['login_email'])) ? $_SESSION['login_email'] : ''; unset($_SESSION['login_email']) ?>">
                        <div id="emailHelp" class = "form-text"></div>
                   </div> 

                   <!--Password-->
                   <div class="mb-4">
                        <label for ="login_password" class= "form-lable">Password</label>
                        <input type="password" class="form-control" name = "login_password" id="password" placeholder ="8-20 characters long"aria-describedby="passwordHelp" minlength="8" maxlength="20" required
                        value="<?php echo (isset($_SESSION['login_password'])) ? $_SESSION['login_password'] : ''; unset($_SESSION['login_password']) ?>">
                        <button type="submit" class="btn btn-success mt-4 w-100" name= "login">Login</button>
                   </div>
                </form>
                <hr width="100%" size="1">
                <p class="mb-0 text-center">
                    Does not have an account ? <a href="register.php" class="text-decoration-none">Sign up</a>
                </p>
                <p class="mb-0 text-center">
                    Admin Register ? <a href="admin_register.php" class="text-decoration-none">Register</a>
                </p>
            </div>
        </div>
    </div>
</section>
