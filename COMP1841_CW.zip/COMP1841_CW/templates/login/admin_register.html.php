<section class="background_theme">
    <div class="container">
        <div class= "row align-items-center justify-content-center" >
            <div class="col-sm-8 col-md-6 col-lg-4 bg-white rounded p-4 shadow">
                <div class="row justify-content-center mb-4 display_web">
                    <h1 class="display-1 text-center ">Post 2 Ask</h1>
                    <hr width="100%" size="1">
                    <h1 class="display-6 text-center" id="login">Admin Register</h1>
                    <div class= "my-1">
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='alert alert-danger text-center h6'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            if(isset($_SESSION['success'])){
                                echo "
                                <div class= 'alert alert-success text-center h6'>
                                    ".$_SESSION['success']."
                                </div>
                                ";
                                unset($_SESSION['success']);
                            }
                        ?>
                    </div>
                </div>
                <form action="" method="post">
                    
                    <!-- Admin code -->
                    <div class="mb-4">
                        <label for="admin_code" class="form-label">Admin code</label>
                        <input type ="text" class= "form-control" name="admin_code" aria-describedby="adminHelp" placeholder="" required>
                        <div id="adminHelp" class = "form-text"></div>
                   </div> 
                   
                   <!-- Email -->
                   <div class="mb-4">
                        <label for="email" class="form-label">Email</label>
                        <input type ="email" class= "form-control" name="email" id="email" aria-describedby="emailHelp" placeholder="abc@email.com" required>
                        <div id="emailHelp" class = "form-text"></div>
                   </div> 
                   <!-- Password -->
                   <div class="mb-4">
                        <label for ="password" class= "form-lable">Password</label>
                        <input type="password" class="form-control" name = "password" id="password" placeholder ="8-20 characters long"aria-describedby="passwordHelp" minlength="8" maxlength="20" required>
                        <button type="submit" class="btn btn-success mt-4 w-100" name="submit">Sign up</button>
                   </div>
                </form>
                <hr width="100%" size="1">
                <p class="mb-0 text-center">
                    Does not have an account ? <a href="register.php" class="text-decoration-none">Sign up</a>
                </p>
                <p class="mb-0 text-center">
                    You're an admin / Have an account ? <a href="login.php" class="text-decoration-none">Login</a>
                </p>
                <hr width="100%" size="1">
                <p class= "text-center">
                    <small>
                        This is for individuals who have been authorised by the owner!
                        If you are authorised, enter the given code to gain access. <br>
                        After gaining access, login as a regular user
                    </small>
                </p>
            </div>
        </div>
    </div>
</section>
