<section class="d-grid ap-2 col-12 mx-auto">
    <!-- Post section -->
    <div class="bg-white rounded px-3 py-2 my-3 border border-3">
        <h1 class="display-4 fw-bold"><?=htmlspecialchars($post['title'],ENT_QUOTES,'UTF-8')?></h1>
        <hr width = "100%" size="1"></hr>
        <h1 class="h5">By: 
            <span class="text-primary">
                <?=htmlspecialchars($post['username'],ENT_QUOTES,'UTF-8')?>
            </span>
            -
            <span class="fs-6 fst-italic text-muted">
                <?=htmlspecialchars($post['creation_date'],ENT_QUOTES,'UTF-8')?>
            </span>
        </h1>

        <h1 class="h6">Module: 
            <span class="text-secondary">
                <?=htmlspecialchars($post['module_name'],ENT_QUOTES,'UTF-8')?>
            </span>
        </h1>
        
        <div class="fs-3 my-4">
            <?=htmlspecialchars($post['content'],ENT_QUOTES,'UTF-8')?>
        </div>
        <div>
            <img src="uploads/<?=htmlspecialchars($post['image'],ENT_QUOTES,'UTF-8')?>" alt="<?=htmlspecialchars($post['image'],ENT_QUOTES,'UTF-8')?>" class="img-fluid">
        </div>
    </div>
    
    <!-- Answer / Comment section -->
    <div class="bg-white rounded px-4 py-2 border border-3">
            <div class="row">
                <form action="add_answer.php" method= "post">
                        <input type="text" class="form-control no-border my-2" name= "add_answer" style="resize: none;" placeholder="Comment" required></input>
                        <input type="hidden" class="form-control" name="post_id" value ="<?=$post['Post_id']?>">
                    <button type="submit" name= "answer" class="btn btn-primary my-1">Comment</button>
                </form>
            </div>
            <!-- View Answer / Comment section -->
            <?php foreach($answers as $answer): ?>
                <div class="row">
                    <div class="border border-2 rounded hstack my-2 p-2">
                        <div class="col-4 col-sm-3 col-lg-2 text-center fw-bold">
                            <?=htmlspecialchars($answer['username'],ENT_QUOTES,'UTF-8')?>
                        </div>
                        <div class="vr"></div>
                        <div class="col-6 col-sm-7 col-lg-9 px-2">
                            <?=htmlspecialchars($answer['content'],ENT_QUOTES,'UTF-8')?>
                        </div>
                        <div class="col col-sm col-lg">
                            <?php if ($answer['user_id'] == $_SESSION['user_id'] || $_SESSION['access'] == 'admin') {
                                echo "<form action='delete_answer.php' method='post' class= ''>
                                    <input type = 'hidden' name='answer_id' value = '".$answer['answer_id']."'>
                                    <input type = 'hidden' name='post_id' value = '".$answer['post_id']."'>
                                    <input type = 'submit' value='Delete' class= 'border-0 btn btn-outline-danger'>
                                </form>";
                            }
                            ?>
                        </div>
                    </div>
                </div> 
            <?php endforeach; ?>
        
    </div>
</section>