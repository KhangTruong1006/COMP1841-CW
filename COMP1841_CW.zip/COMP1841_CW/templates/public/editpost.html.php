<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 px-3 py-2 my-3 shadow">
        <div class="text-center">
            <h2>Edit post</h2>
        </div>
        <hr width="100%" size = "1">
        <div class="d-flex justify-content-center">

            <form action="" method= "post" class="w-75 mx-auto">
                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='text-danger h5'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            ?>
                    </small>
                </p>
                <h4>Title</h4> 
                
                <div class="form-floating">
                    <input type="text" class="form-control" name="title" placeholder="Title" required value="<?=$post['title']?>">
                    <label for="title" class="form-label">Title</label>
                </div>
                
                <h4 class="mt-3">Module</h4>
                <select name="modules" class="form-select form-select-sm" required>
                    <?php foreach($modules as $module): ?>
                        <option value = "<?=htmlspecialchars($module['module_id'],ENT_QUOTES,'UTF-8'); ?>">
                            <?=htmlspecialchars($module['module_name'],ENT_QUOTES,'UTF-8');?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <h4 class="mt-3">Content</h4>
                <div class="form-floating">
                    <textarea class="form-control" placeholder="" name="content" style="height: 100px; resize:none"><?=$post['content']?></textarea>
                    <label for="content">Content</label>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <a href="personal_posts.php" class="btn btn-outline-danger col-2 me-5">Cancel</a>
                    <input type="submit" name="submit" value="Save" class = "col-2 btn btn-primary">
                </div>
                
            </form>
        </div>
    </div>
</section>