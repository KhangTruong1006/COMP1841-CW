<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 px-3 py-2 my-3 shadow">
        <div class="text-center">
            <h2>Create a new post</h2>
        </div>
        <hr width="100%" size="1">
        <div class="d-flex justify-content-center">
            
            <form action="" method="post" class="w-75 mx-auto" enctype="multipart/form-data">
                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='text-danger h5'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            ?>
                    </small>
                </p>

                <h4>Title<span class="text-danger">*</span></h4> 
                <div class="form-floating">
                    <input type="text" class="form-control" name="title" placeholder="" required>
                    <label for="title" class="form-label">Title</label>
                </div>
                
                <h4 class="mt-3">Module<span class="text-danger">*</span></h4>
                <select name="modules" class="form-select form-select-sm" required>
                    <?php foreach($modules as $module): ?>
                        <option value = "<?=htmlspecialchars($module['module_id'],ENT_QUOTES,'UTF-8'); ?>">
                            <?=htmlspecialchars($module['module_name'],ENT_QUOTES,'UTF-8');?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <h4 class="mt-3">Content</h4>
                <div class="form-floating">
                    <textarea class="form-control" placeholder="" name="content" style="height: 100px; resize:none"></textarea>
                    <label for="content">Content</label>
                </div>
                
                <h4 class="mt-3">Image</h4>
                <div class="d-flex">
                    <input type="file" name="fileToUpload" id="fileToUpload" class="col-8">
                    <input type="submit" name="submit" value="Create" class = "col btn btn-primary">
                </div>
                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['file_error'])){
                                echo "
                                    <div class='text-danger h6'>
                                    ".$_SESSION['file_error']."
                                    </div>
                                ";
                                unset($_SESSION['file_error']);
                            }
                            ?>
                    </small>
                </p>
            </form>
        </div>
    </div>
</section>