<section class="d-grid gap-2 col-12 mx-auto">
    <h1 class="text-center display-6 my-2">Manage Your Post</h1>
    <?php foreach($personalPosts as $personalPost): ?>
        <div class="bg-white rounded py-1 mb-2 border border-3 shadow">
        
            <div class="d-flex justify-content-center text-center hstack">
                
                <div class="col-3 col-md-3">
                    <h1 class="fs-5 text-secondary">Module:</h1>
                    <h1 class="fs-5 text-primary">
                        <?=htmlspecialchars($personalPost['module_name'],ENT_QUOTES,'UTF-8');?>
                    </h1>
                    <h1 class="fs-6 fst-italic fw-light">
                        <?=htmlspecialchars($personalPost['creation_date'],ENT_QUOTES,'UTF-8');?>
                    </h1>
                </div>
                
                <div class="vr"></div>
                
                <div class="col">
                    <h1>
                    <?=htmlspecialchars($personalPost['title'],ENT_QUOTES,'UTF-8');?>
                    </h1>
                </div>
                
                <div class="col-2 col-md-1">
                    <a href="editpost.php?post_id=<?=$personalPost['Post_id']?>" class="btn btn-outline-dark btn-sm">Edit</a>
                </div>

                <div class="vr"></div>
                <div class="col-2 col-md-1">
                    <form action="delete_post.php" method="post">
                        <input type="hidden" name= "post_id"value="<?=$personalPost['Post_id']?>">
                        <input type="submit" value="Delete" class= "btn btn-danger btn-sm">
                    </form>
                </div>
            </div>
        
        </div>
    <?php endforeach; ?>
</section>