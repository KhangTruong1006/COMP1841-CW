<section class="d-grid gap-2 col-12 mx-auto">
    <h1 class="text-center display-6 my-2">Posts</h1>
    <?php foreach($posts as $post): ?>
        <a href="post.php?post_id=<?= $post['Post_id']?>" class="btn btn-light btn-lg btn-block shadow m-2">
            <div class="hstack">
                <div class="col-5 col-sm-4">
                    <h1 class="fs-3">
                        <?= htmlspecialchars($post['username'],ENT_QUOTES,'UTF-8')?>
                    </h1>
                    <h1 class="fs-5 text-secondary">  
                        Module: <span class="text-primary"><?= htmlspecialchars($post['module_name'],ENT_QUOTES,'UTF-8')?></span>
                    </h1>
                    <h1 class="fs-6 fst-italic fw-light">
                        <?= htmlspecialchars($post['creation_date'],ENT_QUOTES,'UTF-8')?>
                    </h1>
                </div>
                <div class="vr"></div>
                <div class="col col-sm">
                    <h1 class="h2">
                        <?= htmlspecialchars($post['title'],ENT_QUOTES,'UTF-8')?>
                    </h1>
                </div>
            </div>    
        </a>
    <?php endforeach; ?>
</section>