<section class="d-grid w-75 gap-2 col-12 mx-auto pt-3">
    <p class="text-center h6">
        For the website to work properly, the first module is default and cannot be removed
    </p>
    <p class="text-center h6">
       Therefore, when remove the others, posts will be assigned to the first module automatically
    </p>
    <div class="d-flex justify-content-center">
        <a href="createmodule.php" class="w-50 btn btn-primary">New module</a>
    </div>

    <?php foreach($modules as $module): ?>
        <div class="bg-white rounded mb-2 py-1 border border-2 shadow">
            <div class="d-flex justify-content-center text-center hstack">
                <div class="col col-md col-xxl h1">
                    <?= htmlspecialchars($module['module_name'],ENT_QUOTES,'UTF-8')?>
                </div>
                <div class="col-2 col-md-2 col-xxl-1">
                    <a href="editmodule.php?module_id=<?= htmlspecialchars($module['module_id'],ENT_QUOTES,'UTF-8')?>" class="btn btn-outline-dark">Edit</a>
                </div>
                
                <div class="vr"></div>
                <div class="col-3 col-md-2 col-xxl-1">
                <?php if($module["module_id"] == 1){
                    echo "<form action='' method='post' class=''>
                    <input type='hidden' name='module_id' value='" . htmlspecialchars($module["module_id"], ENT_QUOTES, "UTF-8") . "'>
                    <input type='submit' value='Delete' class='btn btn-danger btn-small disabled'>
                    </form>";
                } 
                else {
                    echo "<form action='deletemodule.php' method='post' class=''>
                    <input type='hidden' name='module_id' value='" . htmlspecialchars($module["module_id"], ENT_QUOTES, "UTF-8") . "'>
                    <input type='submit' value='Delete' class='btn btn-danger btn-small'>
                    </form>";
                }
                ?>

                </div>
            </div>
        </div>
    <?php endforeach; ?>
</section>