<section class="d-grid w-75 gap-2 col-12 mx-auto pt-3">
    <?php foreach($users as $user): ?>
     <div class="bg-white rounded  mb-2 border border-2 shadow">
            <div class="d-flex justify-content-center text-center hstack">
                <div class="col col-sm text-start ms-2">
                    
                    <h1 class="fs-2">
                        <?= htmlspecialchars($user['username'],ENT_QUOTES,'UTF-8')?>
                    </h1>
                
                    <h1 class="fs-6 fw-light text-secondary">
                        <?= htmlspecialchars($user['email'],ENT_QUOTES,'UTF-8')?>
                    </h1>
                
                    <h1 class="fs-6 fst-italic fw-light text-muted">
                        Joined: <span class="text-decoration-underline"><?= htmlspecialchars($user['create_date'],ENT_QUOTES,'UTF-8')?></span>
                    </h1>
                    
                </div>
                <div class="col col-sm-2">
                    <a href="edituser.php?user_id=<?=htmlspecialchars($user['user_id'],ENT_QUOTES,'UTF-8')?>" class="btn btn-outline-dark">Edit</a>
                </div>
                
                <div class="vr"></div>
                <div class="col col-sm-2">
                    <a href="deleteuser.php?user_id=<?=htmlspecialchars($user['user_id'],ENT_QUOTES,'UTF-8')?>" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</section>