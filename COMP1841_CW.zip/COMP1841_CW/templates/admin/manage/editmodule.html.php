<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 px-3 py-2 my-3">
        <div class="text-center">
            <h2 class="display-3">Rename module</h2>
        </div>
        <div class="d-flex justify-content-center">
            <form action="" method="post" class="w-75 mx-auto">

                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='text-danger h5'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            if(isset($_SESSION['success'])){
                                echo "
                                <div class='text-success h5'>
                                ".$_SESSION['success']."
                                </div>
                                ";
                                unset($_SESSION['success']);
                            }
                            ?>
                    </small>
                </p>
                
                <h4>Module name</h4>
                <div class="form-floating">
                    <input type="text" class="form-control" name="module_name" placeholder="" value ="<?=$module['module_name']?>" required>
                    <label for="module_name" class="form-label">Name</label>
                </div>
                
                <div class="d-flex justify-content-end mt-3">
                    <a href="modules.php" class="btn btn-outline-danger col-lg-2  me-lg-5 me-sm-3">Cancel</a>
                    <input type="submit" name="submit" value="Save" class = "col-lg-2 btn btn-primary">
                </div>
            </form>
        </div>
    </div>
    
</section>