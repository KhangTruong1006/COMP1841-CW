<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 shadow px-3 py-2 my-3">
        <div class="text-center">
            <h2 class="display-3">Edit user</h2>
        </div>
        <div class="d-flex justify-content-center">
            <form action="" method="post" class="w-75 mx-auto">
                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='text-danger h5'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            if(isset($_SESSION['success'])){
                                echo "
                                <div class='text-success h5'>
                                ".$_SESSION['success']."
                                </div>
                                ";
                                unset($_SESSION['success']);
                            }
                            ?>
                    </small>
                </p>

                <h4>Username
                        <span class="fs-6 fst-italic text-muted">joined - <?=htmlspecialchars($user['create_date'],ENT_QUOTES,'UTF-8')?></span>
                </h4>
                <div class="form-floating">
                    <input type="text" class="form-control" name="username" placeholder="" value ="<?=htmlspecialchars($user['username'],ENT_QUOTES,'UTF-8')?>" required>
                    <label for="username" class="form-label">Username</label>
                </div>

                <h4 class = "mt-3">Full Name</h4>
                <div class="input-group mb-3">
                    <div class="form-floating">
                       <input type="text" class="form-control" placeholder="First name" aria-label="First name" name = "firstname" value ="<?=htmlspecialchars($user['first_name'],ENT_QUOTES,'UTF-8')?>">
                        <label for="firstname" class="form-label">First</label> 
                    </div>

                    <div class="form-floating">
                        <input type="text" class="form-control" placeholder="Last name" aria-label="First name" name = "lastname" value ="<?=htmlspecialchars($user['last_name'],ENT_QUOTES,'UTF-8')?>">
                        <label for="lastname" class="form-label">Last</label> 
                    </div>
                </div>
                <h4>Email</h4>
                <div class="form-floating">
                    <input type="text" class="form-control" name="email" placeholder="" value ="<?=htmlspecialchars($user['email'],ENT_QUOTES,'UTF-8')?>" disabled readonly>
                    <label for="email" class="form-label">Email</label>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <a href="accounts.php" class="btn btn-outline-danger col-lg-2  me-lg-5 me-sm-3">Cancel</a>
                    <input type="submit" name="submit" value="Save" class = "col-lg-2 btn btn-primary">
                </div>
            </form>
        </div>
        
    </div>
</section>