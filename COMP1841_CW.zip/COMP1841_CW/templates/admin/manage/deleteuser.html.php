<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 px-3 py-2 my-3">
        <div class="d-flex justify-content-center">
            <form action="" method= "post" class="w-75 mx-auto text-center">
                <h4>Want to remove <span class="text-primary"><?=htmlspecialchars($username['username'],ENT_QUOTES,'UTF-8');?></span> ?</h4>
                <div class="mt-3">
                    <a href="accounts.php" class="btn btn-danger col-lg-2  me-lg-5 me-sm-3">Cancel</a>
                    <input type="submit" name="submit" value="Proceed" class = "col-lg-2 btn btn-outline-primary">
                </div>
            </form>
        </div>
    </div>
</section>