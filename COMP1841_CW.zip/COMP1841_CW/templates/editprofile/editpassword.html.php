<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 px-3 py-2 my-2">
        <div class="text-center">
            <h2 class="display-3">Change Password</h2>
        </div>
        <hr width="100%" size = "1">
        <div class="d-flex justify-content-center">
            <form action="" method="post" class="w-75 mx-auto">
                
                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='text-danger h5'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            if(isset($_SESSION['success'])){
                                echo"
                                <div class= 'text-success text-center'>
                                    You can login no! <a href='login.php' class='alert-link>Login</a>'".$_SESSION['success']."
                                <div/>
                                ";
                                unset($_SESSION['success']);
                            }
                            ?>
                    </small>
                </p>
                
                <h4>New Password</h4>
                <div class="form-floating">
                    <input type="password" class="form-control" name="new_password" placeholder = "" requried minlength="8" maxlength="20" value="">
                    <label for="new_password" class="form-label">New</label>
                </div>
                
                <h4 class="mt-3">Confirm Password</h4>
                <div class="form-floating">
                    <input type="password" class="form-control" name="confirm_password" placeholder = "" requried minlength="8" maxlength="20" value="">
                    <label for="confirm_password" class="form-label">Confirm</label>
                </div>    
            
                <hr width="100%" size = "1">
                <h4 class="mt-3">Current Password</h4>
                <div class="form-floating">
                    <input type="password" class="form-control" name="current_password" placeholder = "" requried minlength="8" maxlength="20" value="">
                    <label for="current_password" class="form-label">Current</label>
                </div>

                <div class="d-flex justify-content-end mt-3">
                    <a href="posts.php" class="btn btn-outline-danger col-lg-2  me-lg-5 me-sm-3">Cancel</a>
                    <input type="submit" name="submit" value="Save" class = "col-lg-2 btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</section>