<section class="d-grid w-75 ap-2 col-12 mx-auto">
    <div class="bg-white rounded border border-3 px-3 py-2 my-3">
        <div class="text-center">
            <h2 class="display-3">Edit Email</h2>
        </div>

        <div class="row fs-4 fw-bold">
            <div class="col-lg-2 text-dark fw-bold">Username:</div>
            <div class="col-lg-10 text-primary">
                <?=htmlspecialchars($_SESSION['username'],ENT_QUOTES,'UTF-8');?>
            </div>
        </div>

        <div class="row fs-4 fw-bold my-2">
            <div class="col-lg-2 text-dark fw-bold">Email:</div>
            <div class="col-lg-2 text-primary">
                <?=htmlspecialchars($_SESSION['email'],ENT_QUOTES,'UTF-8');?>
            </div>
        </div>
    
        <hr width="100%" size ="1">
        <div class="d-flex justify-content-center">
            <form action="" method= "post" class="w-75 mx-auto">
                
                <p>
                    <small>
                        <?php 
                            if(isset($_SESSION['error'])){
                                echo "
                                    <div class='text-danger h5'>
                                    ".$_SESSION['error']."
                                    </div>
                                ";
                                unset($_SESSION['error']);
                            }
                            if(isset($_SESSION['success'])){
                                echo"
                                <div class= 'text-success text-center'>
                                    You can login no! <a href='login.php' class='alert-link>Login</a>'".$_SESSION['success']."
                                <div/>
                                ";
                                unset($_SESSION['success']);
                            }
                            ?>
                    </small>
                </p>
                
                <h4>Email</h4>
                <div class="form-floating">
                    <input type="email" class="form-control" name="email" placeholder="" required>
                    <label for="email" class="form-label">Email</label>
                </div>
                
                <h4 class="mt-3">Password</h4>
                <div class="form-floating">
                    <input type="password" class="form-control" name="password" placeholder = "" requried minlength="8" maxlength="20" value="">
                    <label for="password" class="form-label">Password</label>
                </div>
                
                <div class="d-flex justify-content-end mt-3">
                    <a href="posts.php" class="btn btn-outline-danger col-lg-2  me-lg-5 me-sm-3">Cancel</a>
                    <input type="submit" name="submit" value="Save" class = "col-lg-2 btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</section>