<!DOCTYPE html>
<html>
    <head>
        <meta charset = "UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="../post2ask.css">
    </head>
    <body class="min-vh-100 background_color">
        <div class="container-md bg-white rounded p-2 my-3">
            <h1 class="display-1 text-center ">Post 2 Ask</h1>
            <div class = "d-flex justify-content-center ">
                <h1 class="display-5 text-center text-white bg-danger w-50 rounded p-2 fw-bold">Admin</h1>
            </div>
            
            <hr width="100%" size="2">
            <div class= "my-1">
                
            </div>
            <nav class="">
                <ul class="nav nav-tabs nav-justify justify-content-center fs-5">
                    <li>
                        <a href="posts.php" class="nav-link text-decoration-none">Posts</a>
                    </li>
                    <li>
                        <a href="modules.php" class="nav-link text-decoration-none">Modules</a>
                    </li>
                    <li>
                        <a href="accounts.php" class="nav-link text-decoration-none">Accounts</a>
                    </li>
                    <li>
                        <a href="../posts.php" class="nav-link text-decoration-none fw-bold text-success">Public site</a>
                    </li>
                    <li class="nav-item dropdow">
                        <a class="nav-link dropdown-toggle  text-muted" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Others</a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item text-danger" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <main>
                <?=$output?>
            </main>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    </body>
</html>