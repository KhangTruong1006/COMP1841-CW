<?php
session_start();
include "includes/DatabaseConnection.php";
include "includes/DatabaseFunctions.php";  
if (ISSET($_POST['register'])){
    // assign variables to post values
    $email = trim($_POST['register_email']);
    $username = strtolower(trim($_POST['username']));
    $firstname = trim(ucfirst(strtolower($_POST['firstname'])));
    $lastname = trim(ucfirst(strtolower($_POST['lastname'])));
    $password = trim($_POST['register_password']);
    $confirm = trim($_POST['confirm_password']);
    
    // check if user only put white space
    if ($email === '' || $username === '' || $firstname === '' || $lastname === '' || $password === '' || $confirm === '') {
        $_SESSION['register_email'] = $email;
        $_SESSION['username'] = $username;
        $_SESSION['firstname'] = $firstname;
        $_SESSION['lastname'] = $lastname;
        $_SESSION['error'] = $allFieldsRequired;
        header('Location: register.php');
        exit;
    }
    else{
        // check if password matches the confirm one
        if ($password != $confirm){
            $_SESSION['register_email'] = $email;
            $_SESSION['username'] = $username;
            $_SESSION['firstname'] = $firstname;
            $_SESSION['lastname'] = $lastname;

            // display error
            $_SESSION['error'] = 'Password does not match'; 
        }
        else{
            if(preg_match('/^[A-Za-z0-9_]+$/',$username)){
                try{
                    //check if account with the email is existed
                    $exist_account = getAccount($pdo,$email);
                    $exist_username = getUsername($pdo,$username);
                    if ($exist_account->rowCount() > 0){
                        $_SESSION['register_email'] = $email;
                        $_SESSION['username'] = $username;
                        $_SESSION['firstname'] = $firstname;
                        $_SESSION['lastname'] = $lastname;

                        //display error
                        $_SESSION['error'] = 'Email already taken';
                    }
                    elseif($exist_username->rowCount() > 0){
                        $_SESSION['register_email'] = $email;
                        $_SESSION['username'] = $username;
                        $_SESSION['firstname'] = $firstname;
                        $_SESSION['lastname'] = $lastname;

                        //display error
                        $_SESSION['error'] = $usernameTaken;
                    }
                    else{
                        // hasing password
                        $password = password_hash($password, PASSWORD_DEFAULT);
                        insertAccount($pdo,$email,$username,$firstname,$lastname,$password);
                        $_SESSION['success']='User verified. You can login now';
                        //header('Location: login.php');
                    }
                }
                catch(PDOException $e){
                    $_SESSION['error'] = $e->getMessage();
                }
            }
            else{
                $_SESSION['register_email'] = $email;
                $_SESSION['username'] = $username;
                $_SESSION['firstname'] = $firstname;
                $_SESSION['lastname'] = $lastname;
                $_SESSION['error'] = 'Username only allow letters,number and underscore';
            }
        }
    }
    
}

ob_start();
include "templates/login/register.html.php";
$output = ob_get_clean();

include "templates/login_layout.html.php";