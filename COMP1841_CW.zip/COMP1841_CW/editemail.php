<?php
session_start();
include 'includes/DatabaseConnection.php';
include 'includes/DatabaseFunctions.php';

try {
    $user_id = $_SESSION['user_id'];
    if (isset($_POST['submit'])) {
        $input_email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $account = getAccount($pdo,$input_email);
        $current_email_account = getAccount($pdo,$_SESSION['email'])->fetch();
        // check if any is white space
        if ($input_email === '' || $password === ''){
            $_SESSION['error'] = $allFieldsRequired;
            header('Location: editemail.php');
            exit;
        }

        // if input the same current account
        if ($input_email == $_SESSION['email']) {
            $_SESSION['error'] = 'Use different email';
            header('Location: editemail.php');
            exit;
        }
        
        //verify password
        
        if(password_verify($password,$current_email_account['user_password'])){
            // check if input email is taken
            if($account->rowCount() > 0) {
                $_SESSION['error'] = 'This email is already taken';
                header('Location: editemail.php');
                exit;  
            }
            else {
                $_SESSION['success'] = 'Changed email successfully';
                $_SESSION['email'] = $input_email;
                updateNewEmail($pdo,$input_email,$user_id);
                header('Location: editemail.php');
            }
        }
        
        else {
            $_SESSION['error'] = 'Wrong password';
            header('Location: editemail.php');
            exit;
        }
    }
    
    else {
        ob_start();
        include 'templates/editprofile/editemail.html.php';
        $output= ob_get_clean();
    }
    
}

catch(PDOException $e) {
    $output = 'Database error: '.$e->getMessage();
}

include 'templates/layout.html.php';