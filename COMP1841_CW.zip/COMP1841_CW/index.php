<?php session_start();
if ($_SESSION['access'] == 'user'){
    header('Location: posts.php');
}

elseif($_SESSION['access'] == 'admin'){
    header('Location: posts.php');
}

else{
    header('Location: login.php');
}