<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try {

    $user_id = $_GET['user_id'];
    $user = getAccountById($pdo,$user_id);

    if (isset($_POST['submit'])){
        $username = trim(strtolower($_POST['username']));
        $firstname = trim(ucfirst(strtolower($_POST['firstname'])));
        $lastname = trim(ucfirst(strtolower($_POST['lastname'])));
        if ($username === '' || $firstname === '' || $lastname === ''){
            $_SESSION['error'] = $allFieldsRequired;
            header('Location: edituser.php?user_id='.$user_id);
            exit;
        }
        else {
            if($username != $user['username']){
                $exist_user = getUsername($pdo,$username);
                if ($exist_user->rowCount() > 0) {
                    $_SESSION['error'] = $usernameTaken;
                    header('Location: edituser.php?user_id='.$user_id);
                    exit;
                }

                else{
                    $_SESSION['success'] = "Changed successfully";
                    updateUserFullname($pdo,$firstname,$lastname,$user_id);
                    updateNewUsername($pdo,$username,$user_id);
                    header("Location: edituser.php?user_id=$user_id");
                    exit;
                }
            }
            else{
                $_SESSION['success'] = "Changed successfully";
                updateUserFullname($pdo,$firstname,$lastname,$user_id);
                header("Location: edituser.php?user_id=$user_id");
                exit;
            }
        }
    }
    
    else{
        ob_start();
        include '../templates/admin/manage/edituser.html.php';
        $output = ob_get_clean();
    }   
}

catch(PDOException $e){
    $output = 'Database error: '.$e->getMessage();
}

include '../templates/admin_layout.html.php';