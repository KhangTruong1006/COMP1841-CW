<?php 
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try {

    $answer_id = $_POST['answer_id'];
    deleteAnswer($pdo,$answer_id);
    header("Location:post.php?post_id=".$_POST['post_id']);
    exit;
}
catch(PDOException $e){
    $output = "Database error: " . $e->getMessage();
}

include "../templates/admin_layout.html.php";