<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try{
    $user_id = $_GET['user_id'];
    $username = getAccountById($pdo,$user_id);
    
    if(isset($_POST['submit'])) {
        deleteUserAnswers($pdo,$user_id);
        deleteUserPosts($pdo,$user_id);
        deleteUser($pdo,$user_id);
        header('Location: accounts.php');
        exit;
    }
    else{
        ob_start();
        include '../templates/admin/manage/deleteuser.html.php';
        $output = ob_get_clean(); 
    }
    
}
catch(PDOException $e){
    $output = 'Database error: '.$e->getMessage();
}
include '../templates/admin_layout.html.php';