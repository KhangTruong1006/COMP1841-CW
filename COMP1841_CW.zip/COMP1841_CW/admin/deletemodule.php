<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try{
    $module_id = $_POST['module_id'];
    updatePostModule($pdo,$module_id);
    deleteModule($pdo,$module_id);
    header("Location: modules.php");
    exit;
}
catch(PDOException $e){
    $output = 'Database error: '.$e->getMessage();
}
