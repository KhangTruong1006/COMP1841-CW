<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try{
    $users= getUsers($pdo);

    ob_start();
    include '../templates/admin/view/accounts.html.php';
    $output = ob_get_clean();
}

catch (PDOException $e){
    $output = "Database error: " . $e->getMessage();
}

include '../templates/admin_layout.html.php';