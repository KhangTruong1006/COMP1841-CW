<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try{
    $module_id = $_GET['module_id'];
    $module= getModuleName($pdo,$module_id)->fetch();
    if(isset($_POST['submit'])){
        
        $name = trim(ucfirst(strtolower($_POST['module_name'])));
        

        if ($name === ''){
            $_SESSION['error'] = 'Field required';
            header('Location: editmodule.php?module_id='.$_GET['module_id']);
            exit;
        }

        else{
            $_SESSION['success']= 'Change name successfully';
            updateModuleName($pdo,$module_id,$name);
            header('Location: editmodule.php?module_id='.$module_id);
        }
    }

    else{
        ob_start();
        include '../templates/admin/manage/editmodule.html.php';
        $output= ob_get_clean();
    }
}
catch(PDOException $e){
    $output = 'Database error: '.$e->getMessage();
}

include '../templates/admin_layout.html.php';