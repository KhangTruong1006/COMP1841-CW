<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try{
    if(isset($_POST['submit'])){
        $module_name = trim(ucfirst(strtolower($_POST['module_name'])));

        if($module_name === '') {
            $_SESSION['error'] = 'Field required';
            header('Location: createmodule.php');
            exit;
        }

        else{
            insertModule($pdo,$module_name);
            header("Location: modules.php");
            exit;
        }
    }
    else{
        ob_start();
        include '../templates/admin/manage/createmodule.html.php';
        $output= ob_get_clean();
    } 
}

catch(PDOException $e){
    $output = 'Database error: '.$e->getMessage();
}

include '../templates/admin_layout.html.php';