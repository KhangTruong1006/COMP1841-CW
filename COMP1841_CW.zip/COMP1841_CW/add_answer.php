<?php
session_start();
try {
    include "includes/DatabaseConnection.php";
    include "includes/DatabaseFunctions.php";

    if (isset($_POST['answer'])){
        if (isset($_POST['add_answer'])){
            $answer=trim($_POST['add_answer']);
            // if the answer/comment is a white space
            if ($answer === '') {
                header("Location: post.php?post_id=" . $_POST['post_id']);
                exit;
            }
            
            else{
                $user_id = $_SESSION['user_id'];
                $post_id = $_POST['post_id'];
                insertAnswer($pdo,$answer,$user_id,$post_id);
                header("location: post.php?post_id=$post_id");
                exit;
            }
        }
    }
    else {
        ob_start();
        include "templates/public/post.html.php";
        $output = ob_get_clean();
    }
}
catch (PDOException $e){
    $output = "Database error: " .$e->getMessage();
}

include "templates/layout.html.php";