<?php
session_start();
$user_id = $_SESSION['user_id'];

try{
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';
    $modules = getModules($pdo);
    
    if(isset($_POST['submit'])){
        if (isset($_POST['title'])){
            
            // check if title is a white space
            $title=trim($_POST['title']);
            if ($title === ''){
                $_SESSION['error'] = 'Title is required';
                header('Location: create_post.php');
                exit;
            }
            else {
                $user_id = $_SESSION['user_id'];
                $module_id = $_POST['modules'];
                $content = $_POST['content'];

                // Image upload
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
                $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
               
                // Check if image is empty
                if (empty($_FILES["fileToUpload"]["tmp_name"])){
                    $image = null;
                }
                else{
                    // check image if it is real
                    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                    if($check !== false){
                        $uploadOk = 1;
                    }
                    else {
                        $_SESSION['file_error'] = 'The file is not an image. Try again';
                        $uploadOk = 0;
                    }
                    
                    // check image if its name existed
                    if (file_exists($target_file)) {
                        $_SESSION['file_error'] = "The file's name already exist";
                        $uploadOk = 0;
                    }

                    // check image size
                    if ($_FILES["fileToUpload"]["size"]>2 * 1024 * 1024) {
                        $_SESSION['file_error'] = 'The image size must be < 2MB';
                        $uploadOk = 0;
                    }

                    // allow certain formats
                    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
                        $_SESSION['file_error'] = 'Only JPG, JPEG, PNG are allowed';
                        $uploadOk = 0;
                    }

                    // Return to create post 
                    if($uploadOk == 0) {
                        header("location: create_post.php");
                        exit;
                    }
                    
                    // if everything is ok
                    else {
                        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                            $image = $_FILES["fileToUpload"]["name"];
                        }
                        else {
                            $_SESSION['file_error'] = 'An error has occured';
                        }
                    }
                }

               createPost($pdo,$title,$content,$image,$user_id,$module_id);
               header('Location: posts.php');
               exit;
            }
        }
    }
    
    else {
        ob_start();
        include 'templates/public/create_post.html.php';
        $output= ob_get_clean();
    }
}
catch(PDOException $e) {
    $output = 'Database error: '. $e->getMessage();
}

include 'templates/layout.html.php';