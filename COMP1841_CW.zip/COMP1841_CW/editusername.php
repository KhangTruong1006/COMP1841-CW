<?php
session_start();
include 'includes/DatabaseConnection.php';
include 'includes/DatabaseFunctions.php';

try{
    $user_id = $_SESSION['user_id'];
    if(isset($_POST['submit'])){
        $input_username = trim($_POST['username']);
        $password = trim($_POST['password']);
        $account = getAccount($pdo,$_SESSION['email'])->fetch();
        $exist_username = getUsername($pdo,$input_username);
        // check if any is white space
        if ($input_username === '' || $password === ''){
            $_SESSION['error'] = $allFieldsRequired;
            header('Location: editusername.php');
            exit;
        }

        // if input the same current usernam
        if($input_username == $_SESSION['username']){
            $_SESSION['error'] = 'Use different username';
            header('Location: editusername.php');
            exit;
        }

        // allow lowercase letters, numbers and underscore
        if(preg_match('/^[a-z0-9_]+$/',$input_username)){
            // verify password
            if(password_verify($password,$account['user_password'])){
                if ($exist_username->rowCount() > 0){
                    $_SESSION['error'] = 'Username is already taken';
                    header('Location: editusername.php');
                    exit;
                }
                else{
                    $_SESSION['success'] = 'Changed username sucessfully';
                    $_SESSION['username'] = $input_username;
                    updateNewUsername($pdo,$input_username,$user_id);
                    header('Location:editusername.php');
                }
            }
            else{
                $_SESSION['error'] = 'Wrong password';
                header('Location: editusername.php');
                exit;
            }
        }
        
        else {
            $_SESSION['error'] = 'Only allow lowercase letters, numbers and underscore';
            header('Location: editusername.php');
            exit;
        }
    }
    
    else{
        ob_start();
        include 'templates/editprofile/editusername.html.php';
        $output= ob_get_clean();
    }
}

catch(PDOException $e) {
    $output = 'Database error: '.$e->getMessage();
}

include 'templates/layout.html.php';