<?php
session_start();

try {
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';

    $user_id = $_SESSION['user_id'];
    $personalPosts = getPersonalPosts($pdo,$user_id);

    ob_start();
    include 'templates/public/personal_posts.html.php';
    $output = ob_get_clean();
}

catch(PDOException $e) {
    $output = 'Database error: '. $e->getMessage();
}

include 'templates/layout.html.php';