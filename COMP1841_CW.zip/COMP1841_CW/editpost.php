<?php
session_start();
try{
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';

    $post_id = $_GET['post_id'];
    $modules = getModules($pdo);
    $post = getPostDetails($pdo,$post_id);

    if (isset($_POST['submit'])){
        if (isset($_POST['title'])){
            
            $title = trim($_POST['title']);
            if ($title === ''){
                $_SESSION['error'] = 'Title must not empty';
                header('Location: editpost.php?post_id='.$post_id);
                exit;
            }
            else {
                $content = $_POST['content'];
                $module_id = $_POST['modules'];
                updatePost($pdo,$post_id,$title,$content,$module_id);
                header('Location: personal_posts.php');
                exit;
            }
        }
    }
    
    else{
        ob_start();
        include 'templates/public/editpost.html.php';
        $output = ob_get_clean();
    }
}

catch(PDOException $e) {
    $output = 'Database error: '. $e->getMessage();
}

include 'templates/layout.html.php';